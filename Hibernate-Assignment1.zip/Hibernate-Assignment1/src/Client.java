import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
public class Client {
	
private static SessionFactory factory;
	
	public static void getSessionFactory() {
		
		try {
			Configuration conf=new Configuration().configure();
			StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(conf.getProperties());
			factory=conf.buildSessionFactory(builder.build());
		}catch(Throwable ex) {
			System.out.println("Failed to create session factory oject"+ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	
public static void main(String args[]) {
		
		try
		
		{
			getSessionFactory();
			
			Client client_1=new Client();
			
			//add insurance details to the table
			client_1.InsertRecordInDatabase(1,"Shankar",2,7000);
			client_1.InsertRecordInDatabase(2,"Sreeram",1,8000);
			client_1.InsertRecordInDatabase(3,"Shilpa",3,5000);
			client_1.InsertRecordInDatabase(4,"Danish",2,10000);
			client_1.InsertRecordInDatabase(5,"Amulya",2,4000);
			client_1.InsertRecordInDatabase(6,"Vikas",5,15000);
			
			System.out.println("the elements have been inserted succesfully");
			
			//print all the employee details
			
		//	System.out.println("Listing out all the employees");
		//	client_1.DisplayRecords();
			
			//update employee records
			
		/*	System.out.println("updating the employee records");
			client_1.UpdateRecord(1,8000);
			client_1.DisplayRecords();
			
			//Calling the native sql
			
			System.out.println("display data using native sql");
			client_1.DisplayRecords_Native_SQL();
			
			//delete an employee from database
			System.out.println("delete the 3rd record....");
			client_1.DeleteRecord(3);
			
			//list down new list of employees
			client_1.DisplayRecords();
			
			*/
			
			
		}catch(HibernateException e) {
			System.out.println("this error occured during insertion : "+e);
		}
	}
	
	//Method to create an Employee in the database;
	public void InsertRecordInDatabase(int pid, String name, int tenure, int amount)throws HibernateException {
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Insurance i1= new Insurance(pid,name,tenure,amount);
		session.save(i1);
		tx.commit();
		
		session.close();
		
	}
	
	//Method to read all the employee details
	public void DisplayRecords()throws HibernateException {
		Session session=factory.openSession();
		List insLst= session.createQuery("FROM Insurance").list();
		for(Iterator iterator =
				insLst.iterator(); iterator.hasNext();) {
			Insurance insurance=(Insurance)iterator.next();
			System.out.println("the policy id is : "+insurance.getPid());
			System.out.println("the name is : "+insurance.getName());
			System.out.println("the tenure is : "+insurance.getTenure());
			System.out.println("the amount is : "+insurance.getAmount());
		}
		session.close();
	}

	//method to update records
	
	public void UpdateRecord(Integer pid, int amount) {
		
		Session session = factory.openSession();
		Transaction tx= session.beginTransaction();
		
		Insurance insurance = (Insurance)session.get(Insurance.class,pid);
		insurance.setAmount(amount);
		session.update(insurance);
		tx.commit();
		session.close();
	}
	
	//method to delete an employee 
	
	public void DeleteRecord(int pid) {
		
		Session session= factory.openSession();
		Transaction tx=session.beginTransaction();
		Insurance insurance = (Insurance)session.get(Insurance.class, pid);
		session.delete(insurance);
		tx.commit();
		session.close();
	}
	
	


}
