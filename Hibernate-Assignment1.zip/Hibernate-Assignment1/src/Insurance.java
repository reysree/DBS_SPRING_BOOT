import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name = "insurance")
public class Insurance {
	
	@Column(name="name")
	private String name;
	@Id
	private int pid;
	private int tenure;
	private int amount;
	
	public Insurance() {}
	
	public Insurance(int pid, String name,int tenure, int amount) {
		this.pid=pid;
		this.name=name;
		this.tenure=tenure;
		this.amount=amount;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	

}
