import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class Client {
	
private static SessionFactory factory;
	
	public static void getSessionFactory() {
		
		try {
			Configuration conf=new Configuration().configure();
			StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(conf.getProperties());
			factory=conf.buildSessionFactory(builder.build());
		}catch(Throwable ex) {
			System.out.println("Failed to create session factory oject"+ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	
public static void main(String args[]) {
		
		try
		
		{
			getSessionFactory();
			
			Client client_1=new Client();
			
			//add passenger details to the table
			client_1.InsertRecordInDatabase(1,"Shankar","Hyderabad","Mumbai",2000,20);
			client_1.InsertRecordInDatabase(2,"Sreeram","Hyderabad","Chennai",4000,50);
			client_1.InsertRecordInDatabase(3,"Shilpa","Cochin","Manglore",1500,21);
			System.out.println("the elements have been inserted succesfully");
			
			//print all the employee details
			
			//System.out.println("Listing out all the passengers");
			//client_1.DisplayRecords();
			
			//update passenger records
			
		/*	System.out.println("updating the passenger records");
			client_1.UpdateRecord(1,"Lonavla");
			client_1.DisplayRecords();
			

			
			//delete a passenger from database
			System.out.println("delete the 3rd record....");
			client_1.DeleteRecord(3);
			
			//list down new list of passengers
			client_1.DisplayRecords();
			
			*/
			
			
		}catch(HibernateException e) {
			System.out.println("this error occured during insertion : "+e);
		}
	}

		public void InsertRecordInDatabase(int id, String name, String source,String destination, int cost, int age)throws HibernateException {
			
			Session session=factory.openSession();
			Transaction tx=session.beginTransaction();
			Train t1= new Train(id,name,source,destination,cost,age);
			session.save(t1);
			tx.commit();
			
			session.close();
			
		}
		
		public void DisplayRecords()throws HibernateException {
			Session session=factory.openSession();
			Criteria cr=session.createCriteria(Train.class);
			cr.add(Restrictions.gt("age", 25));
			cr.add(Restrictions.lt("age", 45));
			List empLst= cr.list();
			for(Iterator iterator =
					empLst.iterator(); iterator.hasNext();) {
				Train tr=(Train)iterator.next();
				System.out.println("the name is : "+tr.getName());
				System.out.println("the source is : "+tr.getSource());
				System.out.println("the destination is : "+tr.getDestination());
			}
			session.close();
		}
		
		public void UpdateRecord(Integer id, String destination) {
			
			Session session = factory.openSession();
			Transaction tx= session.beginTransaction();
			
			Train train = (Train)session.get(Train.class,id);
			train.setDestination(destination);
			session.update(train);
			tx.commit();
			session.close();
		}
		
		public void DeleteRecord(int id) {
			
			Session session= factory.openSession();
			Transaction tx=session.beginTransaction();
			Train train = (Train)session.get(Train.class, id);
			session.delete(train);
			tx.commit();
			session.close();
		}

}
