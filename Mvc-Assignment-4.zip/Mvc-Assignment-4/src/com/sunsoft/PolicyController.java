package com.sunsoft;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

public class PolicyController {
	
	@RequestMapping("/details")
	public String helloWorld(HttpServletRequest req, HttpServletResponse res, Model m)
	{
		String name = req.getParameter("name");
		int policyno = Integer.parseInt(req.getParameter("policyno"));
		int amount = Integer.parseInt(req.getParameter("amount"));
		
		PolicyHolder.alist.add(new PolicyHolder(name,policyno,amount));
		
		return "index";
		
	}
	
	@RequestMapping("/display")
	public String display(Model m) {

		return "display";
	}
	
	@RequestMapping("/print")
	public String display(HttpServletRequest req, HttpServletResponse res, Model m)
	{
		String name=req.getParameter("name");
		
		for(int i=0;i<PolicyHolder.alist.size();i++) {
			if(PolicyHolder.alist.get(i).getName().equals(name)){
				System.out.println(PolicyHolder.alist.get(i).getName());
				System.out.println(PolicyHolder.alist.get(i).getPolicyid());
				System.out.println(PolicyHolder.alist.get(i).getAmount());
			}
		}
		
		return "index";
		
			
	}
}
