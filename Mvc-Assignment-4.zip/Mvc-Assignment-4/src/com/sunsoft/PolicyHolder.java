package com.sunsoft;
import java.util.*;

public class PolicyHolder {
	
	private String name;
	private int policyid;
	private int amount;
	
	public PolicyHolder(String name , int policyid, int amount) {
		
		this.name=name;
		this.policyid=policyid;
		this.amount=amount;
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPolicyid() {
		return policyid;
	}
	public void setPolicyid(int policyid) {
		this.policyid = policyid;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	static ArrayList<PolicyHolder> alist=new ArrayList<PolicyHolder>();
	

}
