package library.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/display")
public class LibraryController {
	
	@RequestMapping(value="/check",method=RequestMethod.GET)
	public String getDisplay() {
		System.out.println("Called");
		
		Library.alist.add(new Library(1,"Percy Jackson","Rick"));
		Library.alist.add(new Library(2,"Narnia","Lewis"));
		Library.alist.add(new Library(3,"Sherlock Holmes","Arthur"));
		
		
		for(int i=0;i<Library.alist.size();i++)
		{
			System.out.println("The book id : "+Library.alist.get(i).getId()+" is "+Library.alist.get(i).getName()+" whose author is "+Library.alist.get(i).getAuthor());
		}
		
		
		return "book details printed in console";
		
	}

}
