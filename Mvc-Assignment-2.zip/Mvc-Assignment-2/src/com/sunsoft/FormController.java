package com.sunsoft;

import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FormController {
	
	ArrayList<Employee> alist=new ArrayList<Employee>();
	
	Employee emp1= new Employee(1,"sreeram","IBGT","Senior Officer","admin");
	Employee emp2= new Employee(2,"shilpa","MOT","Senior Officer","admin");
	Employee emp3= new Employee(3,"shivani","DATA","Senior Officer","admin");
	Employee emp4= new Employee(4,"saikumar","IBGT","Senior Associate","admin");
	
	@RequestMapping("/login")
	public String helloWorld(HttpServletRequest req, HttpServletResponse res, Model m)
	{
		String name = req.getParameter("name");
		String password = req.getParameter("password");

		alist.add(emp1);
		alist.add(emp2);
		alist.add(emp3);
		alist.add(emp4);
		
		for(int i=0;i<alist.size();i++) {
			
			if(alist.get(i).getName().equals(name) && alist.get(i).getPassword().equals(password)) {
				
				String message ="Succesfully logged in";
				String mid=""+alist.get(i).getId();
				String mname=alist.get(i).getName();
				String mdept=alist.get(i).getDept();
				String mdesignation=alist.get(i).getDesignation();
				m.addAttribute("message",message);
				m.addAttribute("mid",mid);
				m.addAttribute("mname",mname);
				m.addAttribute("mdept",mdept);
				m.addAttribute("mdesignation",mdesignation);
				
				break;
			}
		}
		return "hellopage";
	}
}
