package electricity.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bill")
public class ElectrictyController {
	
	@RequestMapping(value="/check",method=RequestMethod.GET)
	public String getBill(@RequestParam int id) {
		System.out.println("called");
		
		Electricity.alist.add(new Electricity(1,"sreeram",5000));
		Electricity.alist.add(new Electricity(2,"shilpa",3000));
		Electricity.alist.add(new Electricity(3,"danish",11000));
		Electricity.alist.add(new Electricity(4,"amulya",8000));
		
		for(int i=0;i<Electricity.alist.size();i++)
		{
			if(Electricity.alist.get(i).getId()==id)
			{
				int eid=Electricity.alist.get(i).getId();
				String name=Electricity.alist.get(i).getName();
				int bill=Electricity.alist.get(i).getBill();
				
				return "the id "+eid+" belongs to "+name+" whose electricity bill is "+bill;
			}
		}

		return "the entered id is not registered for bill calculation";
}
}
