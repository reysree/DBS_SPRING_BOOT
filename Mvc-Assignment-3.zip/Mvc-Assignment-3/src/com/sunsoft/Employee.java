package com.sunsoft;

public class Employee {
	
	private int Id;
	private String name;
	private String dept;
	private String designation;
	private String password;
	public String getPassword() {
		return password;
	}
	
	public Employee(int Id, String name, String dept, String designation, String password ) {
		
		this.Id=Id;
		this.name=name;
		this.dept=dept;
		this.designation=designation;
		this.password=password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}

}
