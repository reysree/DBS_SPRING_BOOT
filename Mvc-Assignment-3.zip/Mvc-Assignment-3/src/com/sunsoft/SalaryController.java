package com.sunsoft;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;

public class SalaryController {
	@RequestMapping("/salary/{id1}")
	public String helloWorld(@RequestParam ("id") int id, @RequestParam("name") String name,@RequestParam("basic") int basic,
			@RequestParam("hra") int hra,@RequestParam("da") int da,@RequestParam("deductions") int deductions, Model m)
	{
		int gross=basic+hra+da;
		int net=gross-deductions;
	    m.addAttribute("gross", gross);
	    m.addAttribute("net", net);
	    return "hellopage";
	    
	}
}


