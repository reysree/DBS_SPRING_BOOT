package com.sunsoft;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class StudentController {
	
	@RequestMapping("/details")
	public String create(HttpServletRequest req, HttpServletResponse res, Model m)
	{
		String name = req.getParameter("name");
		String id = req.getParameter("id");
		String dept = req.getParameter("dept");
		String section = req.getParameter("section");
		
		Student.alist.add(new Student(name,id,dept,section));
		
		return "index";
		
	}
	
	@RequestMapping("/update")
	public String update(HttpServletRequest req, HttpServletResponse res, Model m)
	{
		String name = req.getParameter("name");
		String id = req.getParameter("id");
		String dept = req.getParameter("dept");
		String section = req.getParameter("section");
		
		for(int i=0;i<Student.alist.size();i++) {
			
			if(Student.alist.get(i).getId().equals(id)) {
				
				Student.alist.set(i, new Student(name,id,dept,section));
				System.out.println("Student record updated successfully");
				break;
			}
		}
		return "index";
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest req, HttpServletResponse res, Model m)
	{
		String id=req.getParameter("id");
		
		for(int i=0;i<Student.alist.size();i++)
		{
			if(Student.alist.get(i).getId().equals(id)) {
				Student.alist.remove(i);
				System.out.println("The Student record has been deleted succesfully");
				break;
			}
		}
		
		return "index";
	}

}
