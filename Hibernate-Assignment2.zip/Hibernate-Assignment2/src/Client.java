import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import oracle.net.TNSAddress.Address;


public class Client {
	
	private static SessionFactory factory;
	
	public static void getSessionFactory() {
		
		try {
			Configuration conf = new Configuration().configure();
			StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(conf.getProperties());
			factory = conf.buildSessionFactory(builder.build());
		}
		
		catch(Throwable ex) {
			System.err.println("Failed to create Session Factory Object "+ex);	
			throw new ExceptionInInitializerError(ex);
		}
	}
	
	public static void main(String args[]) {
		try
		{
			getSessionFactory();
			Client c = new Client();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			Set<Student> c1 = new HashSet<Student>();
			Set<Student> c2 = new HashSet<Student>();
			Set<Student> c3 = new HashSet<Student>();
			Set<Student> c4 = new HashSet<Student>();
			c1.add(new Student(1, "sreeram"));
			c1.add(new Student(2, "Shilpa"));
			c2.add(new Student(3, "Danish"));
			c2.add(new Student(4, "Pranav"));
			c3.add(new Student(5, "rupa"));
			c3.add(new Student(6, "amulya"));
			c4.add(new Student(7, "vikas"));
			c4.add(new Student(8, "alladi"));

			College cl1 = new College("C1", "College 1",c1);
			College cl2 = new College("C2", "College 2",c2);
			College cl3 = new College("C3", "College 3",c3);
			College cl4 = new College("C4", "College 4",c4);

			session.save(cl1);
			session.save(cl2);
			session.save(cl3);
			session.save(cl4);
			tx.commit();
			c.displayRecords();
			
		}
		catch(HibernateException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void displayRecords() throws HibernateException{
		Session session = factory.openSession();

		List stdList = session.createQuery("From Student_otm").list();
		display(stdList);
		List clgList = session.createQuery("From College").list();
		display(clgList);
		List clgstd = session.createQuery("From clgstd").list();
		display(clgstd);
		session.close();
	}
	
	public void display(List obj) {
		for(Iterator iterator = obj.iterator(); iterator.hasNext();) {
			College clg = (College) iterator.next();
			System.out.println(clg.toString());
		}
	}
	
	
}
